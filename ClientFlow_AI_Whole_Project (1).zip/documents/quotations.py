# Quotation generation service.

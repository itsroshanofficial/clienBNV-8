# Inventory analytics service.
